package com.example.mcstatus;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView statusText, versionText, playersText, listText, motdText;
    Handler handler = new Handler();

    Runnable statusRunnable = new Runnable() {
        @Override
        public void run() {
            fetchServerStatus();
            handler.postDelayed(this, 10000); // Mỗi 10 giây
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        versionText = findViewById(R.id.versionText);
        playersText = findViewById(R.id.playersText);
        listText = findViewById(R.id.listText);
        motdText = findViewById(R.id.motdText);
        handler.post(statusRunnable);
    }

    void fetchServerStatus() {
        new Thread(() -> {
            try {
                URL url = new URL("https://api.mcsrvstat.us/2/youcantwin.aternos.me:35084");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) content.append(line);
                in.close();

                JSONObject json = new JSONObject(content.toString());
                boolean online = json.getBoolean("online");

                String version = json.optString("version", "Không rõ");
                JSONObject players = json.optJSONObject("players");
                int onlinePlayers = players != null ? players.optInt("online", 0) : 0;
                int maxPlayers = players != null ? players.optInt("max", 0) : 0;
                String list = "Không có";
                if (players != null && players.has("list")) {
                    list = players.getJSONArray("list").join(", ").replaceAll(""", "");
                }
                JSONObject motdObj = json.optJSONObject("motd");
                String motd = motdObj != null && motdObj.has("clean") ?
                    motdObj.getJSONArray("clean").join(" ").replaceAll(""", "") : "";

                final String finalStatus = online ? "ONLINE" : "OFFLINE";
                final String finalVersion = version;
                final String finalPlayers = onlinePlayers + "/" + maxPlayers;
                final String finalList = list;
                final String finalMotd = motd;

                runOnUiThread(() -> {
                    statusText.setText("Trạng thái: " + finalStatus);
                    versionText.setText("Phiên bản: " + finalVersion);
                    playersText.setText("Người chơi: " + finalPlayers);
                    listText.setText("Danh sách: " + finalList);
                    motdText.setText("MOTD: " + finalMotd);
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
