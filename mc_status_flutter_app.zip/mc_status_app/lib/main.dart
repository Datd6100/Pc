import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MC Server Tracker',
      theme: ThemeData.dark(),
      home: const ServerStatusPage(),
    );
  }
}

class ServerStatusPage extends StatefulWidget {
  const ServerStatusPage({super.key});
  @override
  State<ServerStatusPage> createState() => _ServerStatusPageState();
}

class _ServerStatusPageState extends State<ServerStatusPage> {
  Map<String, dynamic>? data;
  bool isLoading = true;

  Future<void> fetchStatus() async {
    try {
      final response = await http.get(Uri.parse('https://api.mcsrvstat.us/2/youcantwin.aternos.me:35084'));
      final result = json.decode(response.body);
      setState(() {
        data = result;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        data = null;
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchStatus();
    Timer.periodic(const Duration(seconds: 10), (timer) => fetchStatus());
  }

  @override
  Widget build(BuildContext context) {
    final online = data?['online'] == true;
    final players = data?['players'] ?? {};
    final motd = data?['motd']?['clean']?.join(' ') ?? '';
    final version = data?['version'] ?? 'Không rõ';

    return Scaffold(
      appBar: AppBar(title: const Text('MC Server Status')),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    online ? "Server đang ONLINE" : "Server OFFLINE",
                    style: TextStyle(
                      color: online ? Colors.green : Colors.red,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (online) ...[
                    Text("Phiên bản: $version"),
                    Text("MOTD: $motd"),
                    Text("Người chơi: ${players['online'] ?? 0}/${players['max'] ?? '?'}"),
                    Text("Danh sách: ${(players['list'] ?? ['Không có']).join(', ')}"),
                  ]
                ],
              ),
      ),
    );
  }
}
